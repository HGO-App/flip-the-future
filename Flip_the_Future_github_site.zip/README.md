# Flip the Future – digitaal spel

Speel het spel online: open de GitHub Pages-link van deze repository (`https://<gebruikersnaam>.github.io/<repository>/`).

- **Spelen:** open de link in Chrome of Edge op de laptop die aan de beamer hangt. Werkt ook offline als je `index.html` downloadt.
- **Lees mee op de telefoon:** klik in het spel op 📱 naast de timer; teams scannen de QR-code en zien het scenario op hun eigen telefoon.
- **Voorbeeldronde (video):** [Nederlands](video/Flip_the_Future_voorbeeldronde_NL.mp4) · [English](video/Flip_the_Future_voorbeeldronde_EN.mp4)

Ontwikkeld voor HAN Green Office · Wereldburgerschap. Spelconcept, scenario's en vormgeving © HAN Green Office; alleen voor onderwijsgebruik.

Bevat [qrcode-generator](https://github.com/kazuhikoarase/qrcode-generator) (MIT-licentie, © Kazuhiko Arase).
