# Flip the Future – digitaal spel

Live: https://hgo-app.github.io/flip-the-future/

- **Spelen:** open de link in Chrome of Edge op de laptop aan de beamer. Installeer hem als app (knop op de startpagina) om ook zonder internet te spelen.
- **Voor docenten:** https://hgo-app.github.io/flip-the-future/#docent – spel, video, handleiding en printbestanden.
- **Voor studenten (vooraf):** https://hgo-app.github.io/flip-the-future/#voorbereiden – video, waarden, rollen en kaartlezer.
- **Talen:** Nederlands, English, Italiano.
- **Telefoons:** meelezen kan altijd (📱 naast de timer). Teams laten kiezen op hun telefoon, vergelijken met andere groepen en reflecties op de telefoon werken zodra `config.json` het adres van een Firebase Realtime Database bevat.
- **Voorbeeldronde (video):** [NL](video/Flip_the_Future_voorbeeldronde_NL.mp4) · [EN](video/Flip_the_Future_voorbeeldronde_EN.mp4) · [IT](video/Flip_the_Future_voorbeeldronde_IT.mp4)

De scorekaart met de punten staat bewust niet in deze map.

Ontwikkeld voor HAN Green Office · Wereldburgerschap. Spelconcept, scenario's en vormgeving © HAN Green Office; alleen voor onderwijsgebruik.
Bevat [qrcode-generator](https://github.com/kazuhikoarase/qrcode-generator) (MIT-licentie, © Kazuhiko Arase).
