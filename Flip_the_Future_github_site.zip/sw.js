/* Flip the Future: offline cache. Version dfb84fa4d9 */
const CACHE = 'ftf-dfb84fa4d9';
const CORE = ['./', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('ftf-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET') return;
  if (/fonts\.(googleapis|gstatic)\.com$/.test(u.hostname)) { e.respondWith(caches.open(CACHE).then(c => c.match(r).then(m => m || fetch(r).then(res => { c.put(r, res.clone()); return res; })))); return; }
  if (u.origin !== location.origin) return;                       // database and other sites: always live
  if (/\.(mp4|docx|pdf)$/.test(u.pathname) || u.pathname.endsWith('config.json')) return; // large files and settings: from the network
  e.respondWith(fetch(r).then(res => { if (res.ok) caches.open(CACHE).then(c => c.put(r, res.clone())); return res; }).catch(() => caches.match(r).then(m => m || caches.match('index.html'))));
});
